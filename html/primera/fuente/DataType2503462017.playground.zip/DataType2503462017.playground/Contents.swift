//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var firstNumber = 2
var secondNumber = 3
var totalSum = firstNumber + secondNumber

totalSum = firstNumber + secondNumber

print("totalSum = \(totalSum)")





