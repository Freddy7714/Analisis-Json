//: Playground - noun: a place where people can play

import UIKit

var i2:Int
i2=0

// i2=7.95 el valor numerico debe ser igual a la definicion de variable
var i3:Double
var i3=7.95
i3=8

var i4:Float
i4=1.75
i4=5

var srt="Hello Work!"
var cadena:String
cadena="Es una definicion"

cadena="\u{25}"

cadena="\u{0001F497}"

