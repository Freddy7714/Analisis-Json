//: Playground - noun: a place where people can play
//Clase ETPS4 al dia Agosto 11, 2022
import UIKit

var str = "Hello, playground" //Definicion de Variables

/*
 Definicion de Variables
 Implicitas
 Explicitas
 Tipos de Datos
 Ejemplos
*/


//Definiendo Variables
var variable1 = "valor1"
var valor1 = 5
var valor2 = 6
var valor5 = 0
var resultado = 0


//Definiendo constantes
let valor3 = 7
let valor4 = 8
let valor18:Int = 40
let valor19:Int = 6

//Cambiando valor
valor2 = 9
valor1 = 11
valor5 = 15

//Es explicito
var valor15:Int=0
var valor16:Int=5
var valor17:Int

valor15 = 8
valor17 = 75

print(valor17)


print("resultado \(valor17) y otro mas\(valor15)")
resultado = valor15 + valor17
print("Resultado de la suma de \(valor15) mas \(valor17) es \(resultado)")
resultado = valor4 + valor19
print(resultado)

var valor31=4
print(valor31)









