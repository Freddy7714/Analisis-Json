	//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
	
    var valor1:=75
    var valor2:=10
